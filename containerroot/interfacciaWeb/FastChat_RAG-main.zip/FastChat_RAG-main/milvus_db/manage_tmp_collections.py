from milvus import default_server
from pymilvus import connections, utility, Collection

import logging
logging.basicConfig(
    format="%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S", level=logging.INFO
)
logger = logging.getLogger(__name__)


def retrieve_original_data(original_collection_name):
    original_collection = Collection(name=original_collection_name)
    original_data = original_collection.query(expr="", limit=None)
    return original_data

def create_test_collection(test_collection_name, original_collection_schema):
    test_collection = Collection(name=test_collection_name, schema=original_collection_schema)
    return test_collection

def populate_test_collection(test_collection, original_data):
    test_collection.insert(original_data)

def add_new_test_data(test_collection, new_test_data):
    test_collection.insert(new_test_data)

def perform_tests(test_collection):
    pass

def drop_test_collection(test_collection):
    test_collection.drop()

logger.info("Establishing connection with Milvus DB")
try:
    connections.connect("default", host="0.0.0.0")
except:
    logger.info("Starting the server at 0.0.0.0")
    default_server.start()
    connections.connect("default", host="0.0.0.0")

original_collection_name = "CodiceAppalti2023"
test_collection_name = "test_collection"

original_data = retrieve_original_data(original_collection_name)
test_collection = create_test_collection(test_collection_name, Collection(name=original_collection_name).schema)
populate_test_collection(test_collection, original_data)

logger.info(f'collection: {test_collection.name} has {test_collection.num_entities} entities')

drop_test_collection(test_collection)


