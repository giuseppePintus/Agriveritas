#!/bin/bash


DATA_PATH="data/ca_book"
COLLECTION_NAME="CodiceAppalti2023"
EMBED_MODEL="LorMolf/SentenceTransformer_CodiceAppalti"

# DATA_PATH="data_presentation"
# COLLECTION_NAME="PhilosophIA"
# EMBED_MODEL="BAAI/bge-m3"

CHUNK_SIZE=512
CHUNK_OVERLAP=0

CUDA_VISIBLE_DEVICES=0 python3 milvus_db/milvus_interface.py --data_path $DATA_PATH \
                                                                --collection_name $COLLECTION_NAME \
                                                                --embedder_model_name $EMBED_MODEL \
                                                                --chunk_size $CHUNK_SIZE \
                                                                --chunk_overlap $CHUNK_OVERLAP

# CUDA_VISIBLE_DEVICES=0 python3 milvus_db/milvus_interface_philosphia.py --data_path $DATA_PATH \
#                                                                 --collection_name $COLLECTION_NAME \
#                                                                 --embedder_model_name $EMBED_MODEL \
#                                                                 --chunk_size $CHUNK_SIZE \
#                                                                 --chunk_overlap $CHUNK_OVERLAP