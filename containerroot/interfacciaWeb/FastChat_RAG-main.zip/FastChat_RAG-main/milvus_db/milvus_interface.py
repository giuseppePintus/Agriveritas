from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import Milvus
from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.schema import Document
from langchain_experimental.text_splitter import SemanticChunker

from milvus import default_server
from pymilvus import connections, utility, Collection

import glob
import os
from tqdm import tqdm
import json
import argparse

import logging
logging.basicConfig(
    format="%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S", level=logging.INFO
)
logger = logging.getLogger(__name__)


def __get_set_name(file_name):
    set_name = ""
    name = file_name.lower()
    if 'allegato' in name:
        set_name = 'Allegato'
    elif 'dpr' in name:
        set_name = 'D.P.R.'
    elif 'regio' in name:
        set_name = 'Regio Decreto'
    elif 'decreto' in name:
        set_name = 'Decreto Legislativo'
    else:
        set_name = 'Articolo'
    
    return set_name

def __get_article_n(file_name):
    return str(file_name.split('_')[1])

def create_db(data_path: str, 
              collection_name : str,
              embedder_model : HuggingFaceEmbeddings,
              text_splitter : RecursiveCharacterTextSplitter):
    try:
        utility.drop_collection(collection_name)
        logger.info("Dropped previous data")
    except:
        pass
    
    logger.info("Starting data ingestion")

    documents = []
    for file in tqdm(glob.glob(os.path.join(data_path, "*"))):
        if os.path.isdir(file): continue
        with open(file, 'r') as f:
            data = f.read()

            set_name = __get_set_name(file)
            metadata = {
                "source" : "Codice Appalti D.Lgs. 36/2023",
                "user" : 0,
                "file_name" : file,
                "set" : set_name,
                "year" : "2023" if set_name in ['Articolo', 'Allegato'] else '-',
                "art_title" : data.split('\n')[0],
                "art_n" : __get_article_n(file) if set_name in ['Articolo', 'Allegato'] else '-'
            }
            
            documents.append(Document(page_content=data, metadata=metadata))

    logger.info("Creating chunks")
    docs = text_splitter.split_documents(documents)

    logger.info("Embedding data and creating DB at 127.0.0.1:19530")
    _ = Milvus.from_documents(
        docs,
        embedder_model,
        connection_args={"host":  "127.0.0.1", "port": "19530"}, collection_name=collection_name
    )
    logger.info("Completed with success")

def ingest_single_new_data(file_path : str,
                           vector_db : Milvus,
                           new_data_metadata : dict,
                           text_splitter : RecursiveCharacterTextSplitter,
                           user : int = 0):
    
    logger.info("Loading file content")

    with open(file_path, 'r') as f:
        data = f.read()

        set_name = __get_set_name(file)
        metadata = {
            "source" : new_data_metadata['source'],
            "user" : user,
            "file_name" : file,
            "set" : set_name,
            "year" : new_data_metadata['year'],
            "art_title" : new_data_metadata['title'],
            "art_n" : '-'
        }
        
    documents = [Document(page_content=data, metadata=metadata)]

    logger.info("Creating chunks")
    new_docs = text_splitter.split_documents(documents)

    logger.info("Adding new instance to DB")
    vector_db.upsert(new_docs)

    logger.info("Completed with success")

def ingest_new_data(data_path: str, 
                    vector_db : Milvus,
                    new_data_metadata : dict,
                    text_splitter : RecursiveCharacterTextSplitter,
                    user : int = 0):
    
    logger.info("Starting new data ingestion")

    documents = []
    for file in tqdm(glob.glob(os.path.join(data_path, "*"))):
        if os.path.isdir(file): continue
        with open(file, 'r') as f:
            data = f.read()

            set_name = __get_set_name(file)
            _title = new_data_metadata['title']
            metadata = {
                "source" : new_data_metadata['source'],
                "user" : user,
                "file_name" : file,
                "set" : set_name,
                "year" : new_data_metadata['year'],
                "art_title" : _title if '"' in _title else f'"{_title}"',
                "art_n" : '-'
            }
            
            documents.append(Document(page_content=data, metadata=metadata))


    logger.info("Creating chunks")
    new_docs = text_splitter.split_documents(documents)

    logger.info("Adding new instances to DB")
    vector_db.upsert(new_docs)
    logger.info("Completed with success")

def main():    
    parser = argparse.ArgumentParser()
    
    parser.add_argument("--data_path", required=True, type=str, help="Path containing file(s) to store into the DB")
    parser.add_argument("--upload_single_instance", default=False, action="store_true", help="Upload a single data file")
    parser.add_argument("--collection_name", default="CodiceAppalti2023", type=str, help="Name of the database colletion")
    parser.add_argument("--add_to_existing_collection", default=False, action="store_true", help="Add new data to existing DB")
    parser.add_argument("--embedder_model_name", default="LorMolf/SentenceTransformer_CodiceAppalti", type=str, help="Name of the model to use for embedding data")
    parser.add_argument("--chunk_size", default=256, type=int, help="Chunk dimension")
    parser.add_argument("--chunk_overlap", default=100, type=int, help="Chunk overlap value")

    parser.add_argument("--new_data_source", default="Codice Appalti D.Lgs. 36/2023", type=str, help="Source of the new document(s)")
    parser.add_argument("--new_data_year", default=2023, type=int, help="Data of writing for the new document(s)")
    parser.add_argument("--new_data_title", default='-', type=str, help="Title for the new document(s)")

    args = parser.parse_args()

    # >> Establish connection
    logger.info("Establishing connection with Milvus DB")
    try:
        connections.connect("default", host="0.0.0.0")
    except:
        logger.info("Starting the server at 0.0.0.0")
        default_server.start()
        connections.connect("default", host="0.0.0.0")

    # >> Load Model
    logger.info("Loading encoder model")
    embedder = HuggingFaceEmbeddings(model_name=args.embedder_model_name,
                                     model_kwargs={"device": "cuda"})

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=args.chunk_size, 
                                                   chunk_overlap=args.chunk_overlap,
                                                   separators=["\n\n"," ",".",","])

    #text_splitter = SemanticChunker(embedder)

    # >> Start ingestion
    if args.add_to_existing_collection:
        logger.info("Connecting to existing DB")
        vector_db = Milvus(
            embedder,
            connection_args={"host": "127.0.0.1", "port": "19530"},
            collection_name=args.collection_name,
        )

        metadata = {
            'title' : parser.new_data_title,
            'year' : parser.new_data_year,
            'source' : parser.new_data_title,
        }

        logger.info("Adding new data to existing Milvus DB")
        if args.upload_single_instance:
            ingest_single_new_data(args.data_path, vector_db=vector_db, new_data_metadata=metadata, text_splitter=text_splitter)
        else:
            ingest_new_data(args.data_path, vector_db=vector_db, new_data_metadata=metadata, text_splitter=text_splitter)
    else:
        logger.info("Creating a new Milvus DB")
        create_db(args.data_path, collection_name=args.collection_name, embedder_model=embedder, text_splitter=text_splitter)

    collection = Collection(args.collection_name)
    logger.info(f'collection: {collection.name} has {collection.num_entities} entities')


    logger.info("Done")


if __name__ == "__main__":
    main()
