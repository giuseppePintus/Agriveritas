from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import Milvus
from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.schema import Document

from milvus import default_server
from pymilvus import connections, utility, Collection

import glob
import os
from tqdm import tqdm
import json
import argparse

import logging
logging.basicConfig(
    format="%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S", level=logging.INFO
)
logger = logging.getLogger(__name__)

from pymilvus import MilvusClient, DataType


def main():

    logger.info("Establishing connection with Milvus DB")
    try:
        connections.connect("default", host="0.0.0.0")
    except:
        logger.info("Starting the server at 0.0.0.0")
        default_server.start()
        connections.connect("default", host="0.0.0.0")

    collection = Collection("CodiceAppalti2023")
    logger.info(f'collection: {collection.name} has {collection.num_entities} entities')


    # 1. Set up a Milvus client
    client = MilvusClient(
        uri="http://localhost:19530"
    )

    res = client.get_load_state(
        collection_name="CodiceAppalti2023"
    )

    print(res)

if __name__ == '__main__':
    main()